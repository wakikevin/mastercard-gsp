<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Get yourself Equity AutoBranch
MasterCard today</title>
</head>

<body style="margin:0; padding:0; font-family:Myriad Pro, 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size:14px; color:#4f4c4c; background:#cccccc;">
<table width="650" border="0" align="center" cellpadding="0" cellspacing="0" style="background:#ffffff">
<form id="gsp_form" name="gsp_form" action="" method="post">
	  <tr>
	    <td align="left" valign="top" style="margin:0; padding:0; font-family:Myriad Pro, 'Helvetica Neue', Helvetica, Arial, sans-serif; font-size:14px; display:block; color:#4c4c4c;"><a href="http://ke.equitybankgroup.com/" style="border:none; outline:none;"><img src="images/equity-logo.png" width="73" height="38" alt="Equity Bank" style="margin:10px 20px 0;"></a></td>
	    <td align="right" valign="top"><img src="images/mastercard-logo.png" width="73" height="51" alt="Mastercard" style="margin:10px 20px 0;"></td>
  </tr>
	  <tr>
	    <td colspan="2" align="left" valign="top">
   	    <img src="images/main.jpg" alt="Get yourself an Equity AutoBranch
MasterCard today" width="650" height="207" vspace="0" align="top" style="border:none; display:block; margin:0;"></td>
  </tr>
	  <tr>
	    <td colspan="2" align="left" valign="top">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="center" valign="top"><img src="images/success.png" width="48" height="48" alt="Success"  style="margin:20px 0 0;"></td>
      </tr>
              <tr>
                <td align="center" valign="top">
                	<p style="margin:10px 0 50px;">Thank you for your message. <br>
                    	We will get back to you.
                    </p>
                </td>
              </tr>
            </table>
        </td>
  </tr>
 </form>
</table>
</body>
</html>
